-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 02, 2014 at 06:27 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlcafe_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_category`
--

CREATE TABLE IF NOT EXISTS `cafemua_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=37 ;

--
-- Dumping data for table `cafemua_category`
--

INSERT INTO `cafemua_category` (`id`, `name`, `picture`, `enable`) VALUES
(13, 'Cafe', NULL, 1),
(15, 'Nước ép', NULL, 1),
(16, 'Kem', NULL, 1),
(17, 'Yaoua', NULL, 1),
(18, 'Nước uống đóng chai', NULL, 1),
(19, 'Nước chế biến', NULL, 1),
(20, 'Trà', NULL, 1),
(21, 'Sữa', NULL, 1),
(22, 'Ca cao', NULL, 1),
(23, 'Chanh', NULL, 1),
(24, 'Thuốc lá', NULL, 1),
(32, 'Sinh tố', NULL, 1),
(33, 'Trái cây ăn', NULL, 1),
(34, 'Khăn lạnh', NULL, 1),
(35, 'Dua lanh', NULL, 1),
(36, 'Dua da', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_collect_customer`
--

CREATE TABLE IF NOT EXISTS `cafemua_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_collect_general`
--

CREATE TABLE IF NOT EXISTS `cafemua_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cafemua_collect_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_config`
--

CREATE TABLE IF NOT EXISTS `cafemua_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `cafemua_config`
--

INSERT INTO `cafemua_config` (`id`, `param`, `value`) VALUES
(1, 'ROW_PER_PAGE', '12'),
(2, 'EVERY_5_MINUTES', '2000'),
(3, 'GUEST_VISIT', '3167'),
(5, 'DISCOUNT', '0'),
(6, 'NAME', 'CAFE MƯA'),
(7, 'ADDRESS', 'Phạm Thái Bường, P.4, TP.VL'),
(8, 'PHONE', '0916 389 638'),
(9, 'CATEGORY_AUTO', '22'),
(10, 'SWITCH_BOARD_CALL', '1'),
(11, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(12, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_course`
--

CREATE TABLE IF NOT EXISTS `cafemua_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_discount` int(11) NOT NULL,
  `prepare` int(11) NOT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=325 ;

--
-- Dumping data for table `cafemua_course`
--

INSERT INTO `cafemua_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `is_discount`, `prepare`, `enable`) VALUES
(148, 13, 'Cafe đá', 'Cafe đá', 'Ly', 14000, 14000, 14000, 14000, '', 1, 0, 1),
(149, 13, 'Cafe đen', 'Cafe đen', 'Ly', 13000, 13000, 13000, 13000, '', 0, 0, 1),
(150, 13, 'Cafe sữa nóng', 'Cafe sữa nóng', 'Ly', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(151, 13, 'Cafe sữa đá', 'Cafe sữa đá', 'Ly', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(162, 16, 'Kem sôcôla', 'Kem sôcôla', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(163, 16, 'Kem dâu tây', 'Kem dâu tây', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(164, 16, 'Kem cafe ', 'Kem cafe ', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(165, 16, 'Kem sầu riêng', 'Kem sầu riêng', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(166, 16, 'Kem trái cây', 'Kem trái cây', 'Ly', 35000, 35000, 35000, 35000, '', 0, 0, 1),
(167, 16, 'Kem thập cẩm', 'Kem thập cẩm', 'Ly', 35000, 35000, 35000, 35000, '', 0, 0, 1),
(168, 16, 'Kem 3 màu', 'Kem 3 màu', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(169, 20, 'Lipton đá', 'Lipton đá', 'Ly', 14000, 14000, 14000, 14000, '', 0, 0, 1),
(170, 20, 'Lipton nóng', 'Lipton nóng', 'Ly', 13000, 13000, 13000, 13000, '', 0, 0, 1),
(171, 20, 'Lipton mật ong', 'Lipton mật ong', 'Ly', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(172, 20, 'Trà đường nóng', 'Trà đường nóng', 'Ly', 9000, 0, 0, 0, '', 0, 0, 1),
(173, 20, 'Trà đường đá', 'Trà đường đá', 'Ly', 12000, 12000, 12000, 12000, '', 0, 0, 1),
(174, 20, 'Trà chanh nóng', '', 'Ly', 9000, 0, 0, 0, '', 0, 0, 1),
(175, 20, 'Trà chanh đá', 'Trà chanh đá', 'Ly', 14000, 14000, 14000, 14000, '', 0, 0, 1),
(176, 20, 'Lipton sữa đá', 'Lipton sữa đá', 'Ly', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(177, 20, 'Lipton sữa nóng', 'Lipton sữa nóng', 'Ly', 13000, 13000, 13000, 13000, '', 0, 0, 1),
(178, 17, 'Yaoua sữa đá', 'Yaoua sữa đá', 'Ly', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(179, 17, 'Yaoua trái cây', 'Yaoua trái cây', 'Ly', 25000, 25000, 25000, 25000, '', 0, 0, 1),
(180, 17, 'Yaoua dâu tươi', 'Yaoua dâu tươi', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(181, 17, 'Yaoua mơ', '', 'Ly', 15000, 0, 0, 0, '', 0, 0, 1),
(182, 17, 'Yaoua mứt', 'Yaoua mứt', 'Ly', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(183, 17, 'Yaoua cam', 'Yaoua cam', 'Ly', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(184, 17, 'Yaoua hủ', 'Yaoua hủ', 'Hủ', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(185, 18, 'Sting dâu', 'Sting dâu', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(186, 18, 'Đậu nành', 'Đậu nành', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(187, 18, 'Bò húc', 'Bò húc', 'Lon', 17000, 0, 0, 0, '', 0, 0, 1),
(188, 18, 'Number one', 'Number one', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(189, 18, 'Sá xị', 'Sá xị', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(190, 18, 'Pepsi ', 'Pepsi ', 'Lon', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(191, 18, '7 up', '7 up', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(192, 18, 'Trà xanh', 'Trà xanh', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(193, 18, 'Dr.Thanh', 'Dr.Thanh', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(194, 18, 'Cam lon', 'Cam lon', 'Lon', 17000, 0, 0, 0, '', 0, 0, 1),
(195, 18, 'Nước suối', 'Nước suối', 'Chai', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(196, 15, 'Nước ép dâu', 'Nước ép dâu', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(197, 15, 'Nước ép lê', 'Nước ép lê', 'Ly', 20000, 0, 0, 0, '', 0, 0, 1),
(198, 15, 'Nước ép táo', '', 'Ly', 20000, 0, 0, 0, '', 0, 0, 1),
(199, 15, 'Nước ép cà chua', '', 'Ly', 20000, 0, 0, 0, '', 0, 0, 1),
(200, 15, 'Nước ép cà rốt', '', 'Ly', 20000, 0, 0, 0, '', 0, 0, 1),
(201, 15, 'Nước ép cam', 'Nước ép cam', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(202, 19, 'Me đá', 'Me đá', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(203, 19, 'Tắc xí muội', 'Tắc xí muội', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(204, 19, 'Xí muội đá', 'Xí muội đá', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(205, 19, 'Xí muội nóng', '', 'Ly', 10000, 0, 0, 0, '', 0, 0, 1),
(206, 19, 'Rau má thường', 'Rau má thường', 'Ly', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(207, 19, 'Rau má dừa', 'Rau má dừa', 'Ly', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(208, 19, 'Rau má sữa', 'Rau má sữa', 'Ly', 16000, 0, 0, 0, '', 0, 0, 1),
(209, 19, 'Xirô dâu', 'Xirô dâu', 'Ly', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(210, 19, 'Xirô sữa', 'Xirô sữa', 'Ly', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(211, 21, 'Sữa quế', 'Sữa quế', 'Ly', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(212, 21, 'Sữa đá', 'Sữa đá', 'Ly', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(213, 21, 'Sữa tươi đá', 'Sữa tươi đá', 'Ly', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(214, 21, 'Sữa tươi không đá', 'Sữa tươi không đá', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(215, 22, 'Ca cao đá', 'Ca cao đá', 'Ly', 18000, 18000, 18000, 18000, '', 1, 0, 1),
(216, 22, 'Ca cao nóng', 'Ca cao nóng', 'Ly', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(217, 22, 'Ca cao sữa đá', 'Ca cao sữa đá', 'Ly', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(218, 22, 'Ca cao sữa nóng', 'Ca cao sữa nóng', 'Ly', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(219, 19, 'Me da sữa ', 'Me da sữa ', 'Ly', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(220, 23, 'Chanh tươi nóng', 'Chanh tươi nóng', 'Ly', 14000, 14000, 14000, 14000, '', 0, 0, 1),
(222, 23, 'Chanh muối đá', 'Chanh muối đá', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(223, 23, 'Chanh muối nóng', 'Chanh muối nóng', 'Ly', 14000, 14000, 14000, 14000, '', 0, 0, 1),
(224, 23, 'Chanh dây (có hạt)', 'Chanh dây (có hạt)', 'Ly', 25000, 25000, 25000, 25000, '', 0, 0, 1),
(225, 23, 'Chanh tươi đá', 'Chanh tươi đá', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(235, 24, '555 (gói lớn)', '555 (gói lớn)', 'Gói', 40000, 40000, 40000, 40000, '', 0, 0, 1),
(236, 24, 'Mèo gói    (goi lớn)', 'Mèo gói    (goi lớn)', 'Gói', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(237, 24, '555 (điếu)', '555 (điếu)', 'Điếu', 2500, 2500, 2500, 2500, '', 0, 0, 1),
(238, 24, 'Mèo tép', 'Mèo tép', 'Bao', 8000, 8000, 8000, 8000, '', 0, 0, 1),
(239, 24, 'Mèo (điếu)', 'Mèo (điếu)', 'Điếu', 1500, 1500, 1500, 1500, '', 0, 0, 1),
(240, 21, 'bạc xĩu nóng', 'bạc xĩu nóng', 'Ly', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(241, 21, 'bạc xĩu đá', 'bạc xĩu đá', 'Ly', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(242, 21, 'sữa nóng', 'sữa nóng', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(248, 18, 'sting sua', 'sting sua', 'Chai', 25000, 25000, 25000, 25000, '', 0, 0, 1),
(249, 21, 'sữa thêm', 'sữa thêm', 'Ly', 10000, 10000, 10000, 10000, '', 0, 0, 1),
(250, 23, 'Chanh giây (không hạt)', 'Chanh giây (không hạt)', 'Ly', 25000, 25000, 25000, 25000, '', 0, 0, 1),
(251, 23, 'Chanh dây sữa', 'Chanh dây sữa', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(254, 32, 'sinh tố bơ', 'sinh tố bơ', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(255, 32, 'sinh tố mãng cầu', 'sinh tố mãng cầu', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(256, 32, 'sinh tố dâu', 'sinh tố dâu', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(257, 32, 'sinh tố cà chua', 'sinh tố cà chua', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(258, 32, 'sinh tố cà rót', 'sinh tố cà rót', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(259, 32, 'sinh tố chanh giây', 'sinh tố chanh giây', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(260, 32, 'sinh tố chanh tuyết', 'sinh tố chanh tuyết', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(261, 32, 'sinh tố sapô chê', 'sinh tố sapô chê', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(263, 32, 'sinh tố thập cẩm', 'sinh tố thập cẩm', 'Ly', 38000, 38000, 38000, 38000, '', 0, 0, 1),
(264, 32, 'sinh tố tự chọn 2 món', 'sinh tố tự chọn 2 món', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(265, 32, 'sinh tố tự chọn 3 món', 'sinh tố tự chọn 3 món', 'Ly', 35000, 35000, 35000, 35000, '', 0, 0, 1),
(266, 32, 'sinh tố táo', 'sinh tố táo', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(267, 32, 'sinh tố lê', 'sinh tố lê', 'Ly', 20000, 0, 0, 0, '', 0, 0, 1),
(268, 33, 'bơ dầm', 'bơ dầm', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(269, 33, 'mãng cầu dầm', 'mãng cầu dầm', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(270, 33, 'sapô dầm', 'sapô dầm', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(271, 33, 'trái cây dĩa lớn', 'trái cây dĩa lớn', 'Dĩa', 40000, 0, 0, 0, '', 0, 0, 1),
(272, 33, 'tráy cây dĩa nhỏ', '', 'Dĩa', 20000, 0, 0, 0, '', 0, 0, 1),
(273, 33, 'dâu dầm', 'dâu dầm', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(274, 21, 'sữa tươi càfê', 'sữa tươi càfê', 'Ly', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(275, 21, 'sữa tươi bịch', 'sữa tươi bịch', 'Bịch', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(276, 34, 'khăn lạnh', '', 'Cái', 2000, 0, 0, 0, '', 0, 0, 1),
(277, 34, 'khăn nóng', '', 'Cái', 2000, 0, 0, 0, '', 0, 0, 1),
(278, 20, 'trà gừng nóng', 'trà gừng nóng', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1),
(279, 20, 'trà cúc đá', 'trà cúc đá', 'Ly', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(281, 20, 'trà cúc nóng', '', 'Ly', 11000, 0, 0, 0, '', 0, 0, 1),
(282, 20, 'trà gừng đá', 'trà gừng đá', 'Ly', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(284, 20, 'Lipton cam', 'Lipton cam', 'Ly', 12000, 0, 0, 0, '', 0, 0, 1),
(285, 15, 'nước ép thơm', 'nước ép thơm', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(286, 19, 'xirô bạc hà', 'xirô bạc hà', 'Ly', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(287, 21, 'sữa hồng', 'sữa hồng', 'Ly', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(288, 13, 'càfê kem', 'càfê kem', 'Ly', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(293, 18, 'C2', 'C2', 'Chai', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(294, 19, 'Sâm dứa sữa', 'Sâm dứa sữa', 'Ly', 19000, 19000, 19000, 19000, '', 0, 0, 1),
(295, 19, 'sâm dứa bạc hà', 'sâm dứa bạc hà', 'Ly', 16000, 16000, 16000, 16000, '', 0, 0, 1),
(296, 24, 'Meo (gói nhỏ)', '', 'Gói', 20000, 0, 0, 0, '', 0, 0, 1),
(297, 20, 'Lípton mật ong nóng', '', 'Ly', 13000, 0, 0, 0, '', 0, 0, 1),
(298, 17, 'yaoua bạc hà', 'yaoua bạc hà', 'Ly', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(299, 16, 'kem sữa cafe', 'kem sữa cafe', 'Ly', 28000, 0, 0, 0, '', 0, 0, 1),
(300, 32, 'Sinh tố cam', 'Sinh tố cam', 'Ly', 30000, 30000, 30000, 30000, '', 0, 0, 1),
(302, 35, 'dua lanh', 'dua lanh', 'Trái', 17000, 17000, 17000, 17000, '', 0, 0, 1),
(303, 36, 'Dua da', 'Dua da', 'Trái', 18000, 18000, 18000, 18000, '', 0, 0, 1),
(305, 32, 'sinh to ca chua + carot', '', 'Ly', 25000, 0, 0, 0, '', 0, 0, 1),
(307, 15, 'nuoc ep chanh day', '', 'Ly', 20000, 0, 0, 0, '', 0, 0, 1),
(309, 15, 'Ep cam (khong da)', 'Ep cam (khong da)', 'Ly', 20000, 0, 0, 0, '', 0, 0, 1),
(310, 32, 'sinh to hanh phuc', '', 'Ly', 25000, 0, 0, 0, '', 0, 0, 1),
(311, 15, 'nuoc ep 2 mon', 'nuoc ep 2 mon', 'Ly', 35000, 35000, 35000, 35000, '', 0, 0, 1),
(312, 15, 'cam mat ong ', '', 'Ly', 22000, 0, 0, 0, '', 0, 0, 1),
(313, 16, 'kem thap cam trai cay', 'kem thap cam trai cay', 'Ly', 37000, 37000, 37000, 37000, '', 0, 0, 1),
(314, 17, 'yaoua sua da (ly dat biet)', '', 'Ly', 20000, 0, 0, 0, '', 0, 0, 1),
(315, 15, 'cam sua da', 'cam sua da', 'Ly', 35000, 35000, 35000, 35000, '', 0, 0, 1),
(316, 15, 'nuoc ep thap cam', 'nuoc ep thap cam', 'Ly', 40000, 40000, 40000, 40000, '', 0, 0, 1),
(317, 15, 'nước ép cà + cải ', '', 'Ly', 23000, 0, 0, 0, '', 0, 0, 1),
(319, 20, 'tra gung mat ong (nong)', '', 'Ly', 13000, 0, 0, 0, '', 0, 0, 1),
(320, 20, 'lipton xí muôi ', '', 'Ly', 13000, 0, 0, 0, '', 0, 0, 1),
(321, 16, 'kem dua', 'kem dua', 'Ly', 25000, 25000, 25000, 25000, '', 0, 0, 1),
(322, 32, 'sinh to mit', '', 'Ly', 20000, 20000, 20000, 20000, '', 0, 0, 1),
(323, 19, 'xi muoi bac ha', '', 'Ly', 12000, 12000, 12000, 12000, '', 0, 0, 1),
(324, 20, 'lipton bac ha', '', 'Ly', 15000, 15000, 15000, 15000, '', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_customer`
--

CREATE TABLE IF NOT EXISTS `cafemua_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cafemua_customer`
--

INSERT INTO `cafemua_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách Hàng Vãng Lai', 0, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_domain`
--

CREATE TABLE IF NOT EXISTS `cafemua_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cafemua_domain`
--

INSERT INTO `cafemua_domain` (`id`, `name`) VALUES
(1, 'SÂN VƯƠN '),
(2, 'PHONG LANH'),
(4, 'Khách lẻ');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_employee`
--

CREATE TABLE IF NOT EXISTS `cafemua_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `cafemua_employee`
--

INSERT INTO `cafemua_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(1, 'Ly', 'Phục vụ', 1, '0907898744', 'Vĩnh Long', 1700000, '123456789'),
(3, 'Vân Anh', 'Phục vụ', 1, '01886458845', 'Vĩnh Long', 900000, ''),
(4, 'Gia bảo', 'Pha chế', 0, '01222193838', 'Vĩnh Long', 1000000, ''),
(5, 'Thanh Luân', 'Bảo vệ', 0, '01883089355', 'Vĩnh Long', 2500000, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_guest`
--

CREATE TABLE IF NOT EXISTS `cafemua_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `cafemua_guest`
--

INSERT INTO `cafemua_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(52, '42.118.194.80', '1387810601', '1387814201', '42.118.194.80'),
(53, '42.117.212.214', '1387811364', '1387814964', '42.117.212.214');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_order_import`
--

CREATE TABLE IF NOT EXISTS `cafemua_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_order_import_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_order_import`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `cafemua_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_order_import_detail_1` (`idorder`),
  KEY `cafemua_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_order_import_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_paid_customer`
--

CREATE TABLE IF NOT EXISTS `cafemua_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `cafemua_paid_customer`
--

INSERT INTO `cafemua_paid_customer` (`id`, `idcustomer`, `date`, `value`, `note`) VALUES
(18, 1, '2013-05-16', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_paid_employee`
--

CREATE TABLE IF NOT EXISTS `cafemua_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_paid_general`
--

CREATE TABLE IF NOT EXISTS `cafemua_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=81 ;

--
-- Dumping data for table `cafemua_paid_general`
--

INSERT INTO `cafemua_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(66, 2, '2013-04-30', 1500000, 'Tạm tính'),
(80, 12, '2013-04-30', 3250000, 'chi tiền đầu chai cho NV');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `cafemua_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `cafemua_paid_supplier`
--

INSERT INTO `cafemua_paid_supplier` (`id`, `idsupplier`, `date`, `value`, `note`) VALUES
(8, 6, '2012-09-19', 1000000, 'Thử nè được không đó !');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_pay_roll`
--

CREATE TABLE IF NOT EXISTS `cafemua_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idemployee` int(11) NOT NULL,
  `date` date NOT NULL,
  `state` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_pay_roll_1` (`idemployee`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=65 ;

--
-- Dumping data for table `cafemua_pay_roll`
--

INSERT INTO `cafemua_pay_roll` (`id`, `idemployee`, `date`, `state`, `extra`, `late`) VALUES
(1, 1, '2013-08-01', 1, 1, 15),
(2, 1, '2013-09-28', 0, 0, 0),
(3, 1, '2013-10-01', 1, 0, 0),
(4, 1, '2013-10-02', 1, 0, 0),
(5, 1, '2013-10-03', 1, 0, 0),
(6, 1, '2013-10-04', 1, 0, 0),
(7, 1, '2013-10-05', 1, 0, 0),
(8, 1, '2013-10-06', 1, 0, 0),
(9, 1, '2013-10-07', 1, 0, 0),
(10, 1, '2013-10-08', 1, 0, 0),
(11, 1, '2013-10-09', 1, 0, 0),
(12, 1, '2013-10-10', 1, 0, 0),
(13, 1, '2013-10-11', 1, 0, 0),
(14, 1, '2013-10-12', 1, 0, 0),
(15, 1, '2013-10-13', 1, 0, 0),
(16, 1, '2013-10-14', 1, 0, 0),
(17, 1, '2013-10-15', 1, 0, 0),
(18, 1, '2013-10-16', 1, 0, 0),
(19, 1, '2013-10-17', 1, 0, 0),
(20, 1, '2013-10-18', 1, 0, 0),
(21, 1, '2013-10-19', 1, 0, 0),
(22, 1, '2013-10-20', 1, 0, 0),
(23, 1, '2013-10-21', 1, 0, 0),
(24, 1, '2013-10-22', 1, 0, 0),
(25, 1, '2013-10-23', 1, 0, 0),
(26, 1, '2013-10-24', 1, 0, 0),
(27, 1, '2013-10-25', 1, 0, 0),
(28, 1, '2013-10-26', 1, 0, 0),
(29, 1, '2013-10-27', 1, 0, 0),
(30, 1, '2013-10-28', 1, 0, 0),
(31, 1, '2013-10-29', 1, 0, 0),
(32, 1, '2013-10-30', 1, 0, 0),
(33, 1, '2013-10-31', 1, 0, 0),
(34, 1, '2013-08-02', 1, 0, 0),
(35, 1, '2013-08-03', 1, 0, 0),
(36, 1, '2013-08-04', 1, 0, 0),
(37, 1, '2013-08-05', 1, 0, 0),
(38, 1, '2013-09-01', 0, 0, 0),
(39, 1, '2013-08-06', 1, 0, 0),
(40, 1, '2013-08-07', 1, 0, 0),
(41, 1, '2013-08-08', 1, 0, 0),
(42, 1, '2013-08-09', 1, 0, 0),
(43, 1, '2013-08-10', 1, 0, 0),
(44, 1, '2013-08-11', 1, 0, 0),
(45, 1, '2013-08-12', 1, 0, 0),
(46, 1, '2013-08-13', 1, 0, 0),
(47, 1, '2013-08-14', 1, 0, 0),
(48, 1, '2013-08-15', 1, 0, 0),
(49, 1, '2013-08-16', 1, 0, 0),
(50, 1, '2013-08-17', 1, 0, 0),
(51, 1, '2013-08-18', 1, 0, 0),
(52, 1, '2013-08-19', 1, 0, 0),
(53, 1, '2013-08-20', 1, 0, 0),
(54, 1, '2013-08-21', 1, 0, 0),
(55, 1, '2013-08-22', 1, 0, 0),
(56, 1, '2013-08-23', 1, 0, 0),
(57, 1, '2013-08-24', 1, 0, 0),
(58, 1, '2013-08-25', 1, 0, 0),
(59, 1, '2013-08-26', 1, 0, 0),
(60, 1, '2013-08-27', 1, 0, 0),
(61, 1, '2013-08-28', 1, 0, 0),
(62, 1, '2013-08-29', 0, 0, 0),
(63, 1, '2013-08-30', 0, 0, 0),
(64, 1, '2013-08-31', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_r2c`
--

CREATE TABLE IF NOT EXISTS `cafemua_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_r2c_1` (`id_course`),
  KEY `cafemua_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_r2c`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_resource`
--

CREATE TABLE IF NOT EXISTS `cafemua_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cafemua_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cafemua_resource`
--

INSERT INTO `cafemua_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(1, 6, 'abc', 'Bao', 2000, '1');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_session`
--

CREATE TABLE IF NOT EXISTS `cafemua_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `cafemua_session_3` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_session`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_session_detail`
--

CREATE TABLE IF NOT EXISTS `cafemua_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_session_detail`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_store`
--

CREATE TABLE IF NOT EXISTS `cafemua_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cafemua_store`
--

INSERT INTO `cafemua_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_supplier`
--

CREATE TABLE IF NOT EXISTS `cafemua_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `cafemua_supplier`
--

INSERT INTO `cafemua_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(6, 'Coop Mart', '070', 'Vĩnh Long', 'Cung cấp mọi thứ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_table`
--

CREATE TABLE IF NOT EXISTS `cafemua_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=72 ;

--
-- Dumping data for table `cafemua_table`
--

INSERT INTO `cafemua_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(2, 1, 'SV: 19', 0, '0'),
(3, 1, 'SV: 20', 0, '0'),
(4, 1, 'SV: 21', 0, '0'),
(28, 1, 'SV: 22', 1, '0'),
(29, 2, 'PL: 01', 1, '0'),
(30, 2, 'PL: 02', 1, '0'),
(31, 2, 'PL: 03', 1, '0'),
(32, 2, 'PL: 04', 1, '0'),
(33, 2, 'PL: 05', 1, '0'),
(34, 2, 'PL: 06', 1, '0'),
(35, 2, 'PL: 07', 1, '0'),
(36, 2, 'PL: 08', 1, '0'),
(37, 2, 'PL: 09', 1, '0'),
(38, 2, 'PL; 10', 1, '0'),
(39, 2, 'PL: 11', 1, '0'),
(40, 2, 'PL: 12', 1, '0'),
(41, 2, 'PL: 13', 1, '0'),
(42, 2, 'PL: 14', 1, '0'),
(43, 2, 'PL: 15', 1, '0'),
(44, 2, 'PL: 16', 1, '0'),
(45, 2, 'PL: 17', 1, '0'),
(49, 4, '1', 1, '0'),
(50, 4, '2', 1, '0'),
(51, 4, '3', 1, '0'),
(52, 4, '4', 1, '0'),
(53, 4, '5', 1, '0'),
(54, 4, '6', 1, '0'),
(55, 4, '7', 1, '0'),
(56, 4, '8', 1, '0'),
(57, 4, '9', 1, '0'),
(58, 4, '10', 1, '0'),
(63, 1, 'SV: 23', 1, '0'),
(70, 2, 'PL: 18', 1, '0'),
(71, 1, 'SV: 26', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_table_log`
--

CREATE TABLE IF NOT EXISTS `cafemua_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_table_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_term`
--

CREATE TABLE IF NOT EXISTS `cafemua_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `cafemua_term`
--

INSERT INTO `cafemua_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(4, 'Lương Nhân Viên', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0),
(12, 'Tiền Phụ Cấp', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_term_collect`
--

CREATE TABLE IF NOT EXISTS `cafemua_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cafemua_term_collect`
--

INSERT INTO `cafemua_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_tracking`
--

CREATE TABLE IF NOT EXISTS `cafemua_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `cafemua_tracking`
--

INSERT INTO `cafemua_tracking` (`id`, `date_start`, `date_end`) VALUES
(8, '2014-02-01', '2014-02-28'),
(9, '2014-03-01', '2014-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_tracking_course`
--

CREATE TABLE IF NOT EXISTS `cafemua_tracking_course` (
  `id` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `prepare` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cafemua_tracking_course`
--

INSERT INTO `cafemua_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`, `prepare`) VALUES
(0, 9, 246, 148, 2, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `cafemua_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `cafemua_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=275 ;

--
-- Dumping data for table `cafemua_tracking_daily`
--

INSERT INTO `cafemua_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(244, 9, '2014-03-01', 0, 0, 0, 0, 0),
(245, 9, '2014-03-02', 0, 0, 0, 0, 0),
(246, 9, '2014-03-03', 28000, 0, 0, 0, 0),
(247, 9, '2014-03-04', 0, 0, 0, 0, 0),
(248, 9, '2014-03-05', 0, 0, 0, 0, 0),
(249, 9, '2014-03-06', 0, 0, 0, 0, 0),
(250, 9, '2014-03-07', 0, 0, 0, 0, 0),
(251, 9, '2014-03-08', 0, 0, 0, 0, 0),
(252, 9, '2014-03-09', 0, 0, 0, 0, 0),
(253, 9, '2014-03-10', 0, 0, 0, 0, 0),
(254, 9, '2014-03-11', 0, 0, 0, 0, 0),
(255, 9, '2014-03-12', 0, 0, 0, 0, 0),
(256, 9, '2014-03-13', 0, 0, 0, 0, 0),
(257, 9, '2014-03-14', 0, 0, 0, 0, 0),
(258, 9, '2014-03-15', 0, 0, 0, 0, 0),
(259, 9, '2014-03-16', 0, 0, 0, 0, 0),
(260, 9, '2014-03-17', 0, 0, 0, 0, 0),
(261, 9, '2014-03-18', 0, 0, 0, 0, 0),
(262, 9, '2014-03-19', 0, 0, 0, 0, 0),
(263, 9, '2014-03-20', 0, 0, 0, 0, 0),
(264, 9, '2014-03-21', 0, 0, 0, 0, 0),
(265, 9, '2014-03-22', 0, 0, 0, 0, 0),
(266, 9, '2014-03-23', 0, 0, 0, 0, 0),
(267, 9, '2014-03-24', 0, 0, 0, 0, 0),
(268, 9, '2014-03-25', 0, 0, 0, 0, 0),
(269, 9, '2014-03-26', 0, 0, 0, 0, 0),
(270, 9, '2014-03-27', 0, 0, 0, 0, 0),
(271, 9, '2014-03-28', 0, 0, 0, 0, 0),
(272, 9, '2014-03-29', 0, 0, 0, 0, 0),
(273, 9, '2014-03-30', 0, 0, 0, 0, 0),
(274, 9, '2014-03-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_tracking_store`
--

CREATE TABLE IF NOT EXISTS `cafemua_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cafemua_tracking_store`
--


-- --------------------------------------------------------

--
-- Table structure for table `cafemua_unit`
--

CREATE TABLE IF NOT EXISTS `cafemua_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `cafemua_unit`
--

INSERT INTO `cafemua_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(11, 'Cái'),
(12, 'Cây'),
(13, 'Giờ'),
(14, 'Bao'),
(15, 'Con'),
(16, 'Kg'),
(17, 'Hộp'),
(18, 'Hủ'),
(19, 'Trái');

-- --------------------------------------------------------

--
-- Table structure for table `cafemua_user`
--

CREATE TABLE IF NOT EXISTS `cafemua_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `cafemua_user`
--

INSERT INTO `cafemua_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(9, 'Bán hàng', 'banhang@gmail.com', '123456', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cafemua_collect_customer`
--
ALTER TABLE `cafemua_collect_customer`
  ADD CONSTRAINT `cafemua_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `cafemua_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_collect_general`
--
ALTER TABLE `cafemua_collect_general`
  ADD CONSTRAINT `cafemua_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `cafemua_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_course`
--
ALTER TABLE `cafemua_course`
  ADD CONSTRAINT `cafemua_course_1` FOREIGN KEY (`idcategory`) REFERENCES `cafemua_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_order_import`
--
ALTER TABLE `cafemua_order_import`
  ADD CONSTRAINT `cafemua_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafemua_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_order_import_detail`
--
ALTER TABLE `cafemua_order_import_detail`
  ADD CONSTRAINT `cafemua_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `cafemua_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafemua_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `cafemua_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_paid_customer`
--
ALTER TABLE `cafemua_paid_customer`
  ADD CONSTRAINT `cafemua_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `cafemua_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_paid_employee`
--
ALTER TABLE `cafemua_paid_employee`
  ADD CONSTRAINT `cafemua_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `cafemua_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_paid_general`
--
ALTER TABLE `cafemua_paid_general`
  ADD CONSTRAINT `cafemua_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `cafemua_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_paid_supplier`
--
ALTER TABLE `cafemua_paid_supplier`
  ADD CONSTRAINT `cafemua_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafemua_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_pay_roll`
--
ALTER TABLE `cafemua_pay_roll`
  ADD CONSTRAINT `cafemua_pay_roll_1` FOREIGN KEY (`idemployee`) REFERENCES `cafemua_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_r2c`
--
ALTER TABLE `cafemua_r2c`
  ADD CONSTRAINT `cafemua_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `cafemua_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafemua_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `cafemua_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_resource`
--
ALTER TABLE `cafemua_resource`
  ADD CONSTRAINT `cafemua_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `cafemua_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_session`
--
ALTER TABLE `cafemua_session`
  ADD CONSTRAINT `cafemua_session_1` FOREIGN KEY (`idtable`) REFERENCES `cafemua_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafemua_session_2` FOREIGN KEY (`iduser`) REFERENCES `cafemua_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafemua_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `cafemua_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_session_detail`
--
ALTER TABLE `cafemua_session_detail`
  ADD CONSTRAINT `cafemua_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `cafemua_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafemua_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `cafemua_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_table`
--
ALTER TABLE `cafemua_table`
  ADD CONSTRAINT `cafemua_table_1` FOREIGN KEY (`iddomain`) REFERENCES `cafemua_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cafemua_table_log`
--
ALTER TABLE `cafemua_table_log`
  ADD CONSTRAINT `cafemua_table_log_ibfk_1` FOREIGN KEY (`idtable`) REFERENCES `cafemua_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cafemua_table_log_ibfk_2` FOREIGN KEY (`iduser`) REFERENCES `cafemua_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
