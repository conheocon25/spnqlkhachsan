-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 11, 2014 at 07:12 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `qlnhatro_demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_collect_customer`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nhatrovanhuynh_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `nhatrovanhuynh_collect_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_collect_general`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nhatrovanhuynh_collect_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `nhatrovanhuynh_collect_general`
--


-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_config`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `nhatrovanhuynh_config`
--

INSERT INTO `nhatrovanhuynh_config` (`id`, `param`, `value`) VALUES
(1, 'ROW_PER_PAGE', '12'),
(2, 'EVERY_5_MINUTES', '2000'),
(3, 'GUEST_VISIT', '3167'),
(5, 'DISCOUNT', '0'),
(6, 'NAME', 'NHÀ TRỌ VÂN HUỲNH'),
(7, 'ADDRESS', 'Phú Quới Long Hồ Vĩnh Long'),
(8, 'PHONE', '0919 153 189'),
(9, 'CATEGORY_AUTO', '22'),
(10, 'SWITCH_BOARD_CALL', '1'),
(11, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(12, 'N_MONTH_LOG', '1'),
(13, 'PRICE_ELECTRIC', '2000'),
(14, 'PRICE_WATER', '5000');

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_customer`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `nhatrovanhuynh_customer`
--

INSERT INTO `nhatrovanhuynh_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách Hàng Vãng Lai', 0, '', '', '', '', 0),
(2, 'ABC', 1, '121324345', '01912132344', '', 'abcfdgfg', 12);

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_domain`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `nhatrovanhuynh_domain`
--

INSERT INTO `nhatrovanhuynh_domain` (`id`, `name`) VALUES
(1, 'DÃY PHÒNG A'),
(2, 'DÃY PHÒNG B');

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_employee`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=19 ;

--
-- Dumping data for table `nhatrovanhuynh_employee`
--

INSERT INTO `nhatrovanhuynh_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(1, 'Quản lý 1', 'Phục vụ', 1, '0919 11 22 33', 'Vĩnh Long', 1200000, '123456789'),
(2, 'Quản lý 2', 'Phục vụ', 1, '0919 22 33 44', 'Vĩnh Long', 1200000, '');

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_guest`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `nhatrovanhuynh_guest`
--

INSERT INTO `nhatrovanhuynh_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(52, '42.118.194.80', '1387810601', '1387814201', '42.118.194.80'),
(53, '42.117.212.214', '1387811364', '1387814964', '42.117.212.214');

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_paid_employee`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `nhatrovanhuynh_paid_employee`
--


-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_paid_general`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nhatrovanhuynh_paid_1` (`id_term`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=81 ;

--
-- Dumping data for table `nhatrovanhuynh_paid_general`
--

INSERT INTO `nhatrovanhuynh_paid_general` (`id`, `id_term`, `date`, `value`, `note`) VALUES
(66, 2, '2013-04-30', 1500000, 'Tạm tính');

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_session`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `nhatrovanhuynh_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `nhatrovanhuynh_session`
--

INSERT INTO `nhatrovanhuynh_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `note`, `status`, `value`) VALUES
(3, 2, 1, 1, 2, '2014-03-11 00:00:00', 'Them mau', 1, 0),
(4, 2, 1, 1, 1, '2014-03-11 00:00:00', 'Them mau', 0, 0),
(5, 3, 1, 1, 2, '2014-03-11 00:00:00', 'Them mau1', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_table`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=72 ;

--
-- Dumping data for table `nhatrovanhuynh_table`
--

INSERT INTO `nhatrovanhuynh_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(2, 1, 'P01', 1, '0'),
(3, 1, 'P02', 1, '0'),
(4, 1, 'P03', 1, '0'),
(28, 1, 'P04', 1, '0'),
(29, 2, 'P11', 1, '0'),
(30, 2, 'P12', 1, '0'),
(31, 2, 'P13', 1, '0'),
(32, 2, 'P14', 1, '0'),
(33, 2, 'P15', 1, '0'),
(34, 2, 'P16', 1, '0'),
(63, 1, 'P05', 1, '0'),
(71, 1, 'P06', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_term`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `nhatrovanhuynh_term`
--

INSERT INTO `nhatrovanhuynh_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_term_collect`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `nhatrovanhuynh_term_collect`
--

INSERT INTO `nhatrovanhuynh_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_tracking`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `nhatrovanhuynh_tracking`
--

INSERT INTO `nhatrovanhuynh_tracking` (`id`, `date_start`, `date_end`) VALUES
(8, '2014-02-01', '2014-02-28'),
(9, '2014-03-01', '2014-03-31');

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `nhatrovanhuynh_tracking_customer`
--


-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=275 ;

--
-- Dumping data for table `nhatrovanhuynh_tracking_daily`
--

INSERT INTO `nhatrovanhuynh_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(244, 9, '2014-03-01', 0, 0, 0, 0, 0),
(245, 9, '2014-03-02', 0, 0, 0, 0, 0),
(246, 9, '2014-03-03', 28000, 0, 0, 0, 0),
(247, 9, '2014-03-04', 0, 0, 0, 0, 0),
(248, 9, '2014-03-05', 0, 0, 0, 0, 0),
(249, 9, '2014-03-06', 0, 0, 0, 0, 0),
(250, 9, '2014-03-07', 0, 0, 0, 0, 0),
(251, 9, '2014-03-08', 0, 0, 0, 0, 0),
(252, 9, '2014-03-09', 0, 0, 0, 0, 0),
(253, 9, '2014-03-10', 0, 0, 0, 0, 0),
(254, 9, '2014-03-11', 0, 0, 0, 0, 0),
(255, 9, '2014-03-12', 0, 0, 0, 0, 0),
(256, 9, '2014-03-13', 0, 0, 0, 0, 0),
(257, 9, '2014-03-14', 0, 0, 0, 0, 0),
(258, 9, '2014-03-15', 0, 0, 0, 0, 0),
(259, 9, '2014-03-16', 0, 0, 0, 0, 0),
(260, 9, '2014-03-17', 0, 0, 0, 0, 0),
(261, 9, '2014-03-18', 0, 0, 0, 0, 0),
(262, 9, '2014-03-19', 0, 0, 0, 0, 0),
(263, 9, '2014-03-20', 0, 0, 0, 0, 0),
(264, 9, '2014-03-21', 0, 0, 0, 0, 0),
(265, 9, '2014-03-22', 0, 0, 0, 0, 0),
(266, 9, '2014-03-23', 0, 0, 0, 0, 0),
(267, 9, '2014-03-24', 0, 0, 0, 0, 0),
(268, 9, '2014-03-25', 0, 0, 0, 0, 0),
(269, 9, '2014-03-26', 0, 0, 0, 0, 0),
(270, 9, '2014-03-27', 0, 0, 0, 0, 0),
(271, 9, '2014-03-28', 0, 0, 0, 0, 0),
(272, 9, '2014-03-29', 0, 0, 0, 0, 0),
(273, 9, '2014-03-30', 0, 0, 0, 0, 0),
(274, 9, '2014-03-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `nhatrovanhuynh_user`
--

CREATE TABLE IF NOT EXISTS `nhatrovanhuynh_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `nhatrovanhuynh_user`
--

INSERT INTO `nhatrovanhuynh_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(1, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, ''),
(9, 'Bán hàng', 'banhang@gmail.com', '123456', 1, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `nhatrovanhuynh_collect_customer`
--
ALTER TABLE `nhatrovanhuynh_collect_customer`
  ADD CONSTRAINT `nhatrovanhuynh_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `nhatrovanhuynh_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nhatrovanhuynh_collect_general`
--
ALTER TABLE `nhatrovanhuynh_collect_general`
  ADD CONSTRAINT `nhatrovanhuynh_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `nhatrovanhuynh_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nhatrovanhuynh_paid_employee`
--
ALTER TABLE `nhatrovanhuynh_paid_employee`
  ADD CONSTRAINT `nhatrovanhuynh_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `nhatrovanhuynh_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nhatrovanhuynh_paid_general`
--
ALTER TABLE `nhatrovanhuynh_paid_general`
  ADD CONSTRAINT `nhatrovanhuynh_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `nhatrovanhuynh_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nhatrovanhuynh_session`
--
ALTER TABLE `nhatrovanhuynh_session`
  ADD CONSTRAINT `nhatrovanhuynh_session_1` FOREIGN KEY (`idtable`) REFERENCES `nhatrovanhuynh_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nhatrovanhuynh_session_2` FOREIGN KEY (`iduser`) REFERENCES `nhatrovanhuynh_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `nhatrovanhuynh_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `nhatrovanhuynh_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nhatrovanhuynh_table`
--
ALTER TABLE `nhatrovanhuynh_table`
  ADD CONSTRAINT `nhatrovanhuynh_table_1` FOREIGN KEY (`iddomain`) REFERENCES `nhatrovanhuynh_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
